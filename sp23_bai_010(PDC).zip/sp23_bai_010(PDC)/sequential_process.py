import os
import time
from PIL import Image, ImageDraw, ImageFont


input_dir = "/mnt/d/6th Semester/parallel/Parallel Lab/myImg"        # Input folder
output_dir = "/mnt/d/6th Semester/parallel/Parallel Lab/output_seq"  # Output folder
watermark_text = "Areeba AI"                                         # Watermark text



def add_watermark(image, text):
    draw = ImageDraw.Draw(image)
    font_size = int(image.size[0] / 10)

    try:
        font = ImageFont.truetype("arial.ttf", font_size)
    except:
        font = ImageFont.load_default()

    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]

    position = (image.size[0] - text_width - 10, image.size[1] - text_height - 10)
    draw.text(position, text, font=font, fill=(255, 255, 255, 128))

    return image



def process_images():
    start_time = time.perf_counter()  # High-precision timer

    for root, dirs, files in os.walk(input_dir):
        for file in files:
            if file.lower().endswith((".jpg", ".jpeg", ".png")):
                input_path = os.path.join(root, file)

                # Keep subfolder structure
                relative_path = os.path.relpath(root, input_dir)
                output_path = os.path.join(output_dir, relative_path)
                os.makedirs(output_path, exist_ok=True)

                # Open, resize, watermark, and save
                img = Image.open(input_path).convert("RGB")
                img = img.resize((128, 128))
                img = add_watermark(img, watermark_text)

                output_file_path = os.path.join(output_path, file)
                img.save(output_file_path)

    end_time = time.perf_counter()
    print(f"Sequential Processing Time: {end_time - start_time:.2f} seconds")



if __name__ == "__main__":
    process_images()
