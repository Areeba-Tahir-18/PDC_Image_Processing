import os
import time
from PIL import Image, ImageDraw, ImageFont
from multiprocessing import Pool, cpu_count


input_dir = "/mnt/d/6th Semester/parallel/Parallel Lab/myImg"
output_dir = "/mnt/d/6th Semester/parallel/Parallel Lab/output_distributed"
watermark_text = "Areeba AI"



def add_watermark(image, text):
    draw = ImageDraw.Draw(image)
    font_size = int(image.size[0] / 10)
    try:
        font = ImageFont.truetype("arial.ttf", font_size)
    except:
        font = ImageFont.load_default()

    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]

    position = (image.size[0] - text_width - 10, image.size[1] - text_height - 10)
    draw.text(position, text, font=font, fill=(255, 255, 255, 128))
    return image



def process_image(task):
    input_path, node_id = task
    try:
        relative_path = os.path.relpath(os.path.dirname(input_path), input_dir)
        output_path = os.path.join(output_dir, f"node_{node_id}", relative_path)
        os.makedirs(output_path, exist_ok=True)

        img = Image.open(input_path).convert("RGB")
        img = img.resize((128, 128))
        img = add_watermark(img, watermark_text)

        output_file_path = os.path.join(output_path, os.path.basename(input_path))
        img.save(output_file_path)

        return 1  # successfully processed
    except Exception as e:
        print(f"Node {node_id} error on {input_path}: {e}")
        return 0



if __name__ == "__main__":
    # Collect all images
    image_paths = []
    for root, dirs, files in os.walk(input_dir):
        for file in files:
            if file.lower().endswith((".jpg", ".jpeg", ".png")):
                image_paths.append(os.path.join(root, file))

    total_images = len(image_paths)
    if total_images == 0:
        print("No images found in input directory.")
        exit()

    # Divide images equally among two nodes
    mid = total_images // 2
    node1_tasks = [(path, 1) for path in image_paths[:mid]]
    node2_tasks = [(path, 2) for path in image_paths[mid:]]

    print("Starting distributed processing using multiprocessing.Pool...\n")
    start_total = time.time()

    # Create two pools representing two “nodes”
    with Pool(processes=2) as pool:
        node1_start = time.time()
        node1_results = pool.map(process_image, node1_tasks)
        node1_time = time.time() - node1_start

    with Pool(processes=2) as pool:
        node2_start = time.time()
        node2_results = pool.map(process_image, node2_tasks)
        node2_time = time.time() - node2_start

    total_time = time.time() - start_total

    
    node1_count = sum(node1_results)
    node2_count = sum(node2_results)

    sequential_time = 18.2
    efficiency = sequential_time / total_time

    print(f"Node 1 processed {node1_count} images in {node1_time:.2f}s")
    print(f"Node 2 processed {node2_count} images in {node2_time:.2f}s")
    print(f"Total distributed time: {total_time:.2f}s")
    print(f"Efficiency: {efficiency:.2f}x over sequential")
