import os
import time
from PIL import Image, ImageDraw, ImageFont
from multiprocessing import Pool, cpu_count

input_dir = "/mnt/d/6th Semester/parallel/Parallel Lab/myImg"
output_dir = "/mnt/d/6th Semester/parallel/Parallel Lab/output_parallel"
watermark_text = "Areeba AI"

def add_watermark(image, text):
    draw = ImageDraw.Draw(image)
    font_size = int(image.size[0] / 10)
    try:
        font = ImageFont.truetype("arial.ttf", font_size)
    except:
        font = ImageFont.load_default()

    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    position = (image.size[0] - text_width - 10, image.size[1] - text_height - 10)
    draw.text(position, text, font=font, fill=(255, 255, 255, 128))
    return image



def process_single_image(input_path):
    try:
        relative_path = os.path.relpath(os.path.dirname(input_path), input_dir)
        output_path = os.path.join(output_dir, relative_path)
        os.makedirs(output_path, exist_ok=True)

        img = Image.open(input_path).convert("RGB")
        img = img.resize((128, 128))
        img = add_watermark(img, watermark_text)

        output_file_path = os.path.join(output_path, os.path.basename(input_path))
        img.save(output_file_path)
        return True
    except Exception as e:
        print(f"Error processing {input_path}: {e}")
        return False



def parallel_process(num_workers):
    start_time = time.perf_counter()  # high-precision timer

    image_paths = []
    for root, dirs, files in os.walk(input_dir):
        for file in files:
            if file.lower().endswith((".jpg", ".jpeg", ".png")):
                image_paths.append(os.path.join(root, file))

    with Pool(num_workers) as pool:
        pool.map(process_single_image, image_paths)

    end_time = time.perf_counter()
    return end_time - start_time


if __name__ == "__main__":
    available_cores = os.cpu_count()
    print(f" Available CPU cores: {available_cores}\n")

    
    workers_list = [1, 2, 4, 8]
    workers_list = [w for w in workers_list if w <= available_cores]

    base_time = None
    results = []

    print("Workers | Time (s) | Speedup")
    print("-------- | -------- | -------")

    for workers in workers_list:
        elapsed = parallel_process(workers)
        if base_time is None:
            base_time = elapsed
        speedup = base_time / elapsed if elapsed > 0 else 0
        results.append((workers, elapsed, speedup))
        print(f"{workers:<8} | {elapsed:<8.2f} | {speedup:<.2f}x")

    print("\nParallel processing completed successfully!")
